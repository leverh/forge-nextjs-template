# Forge

A dark landing page inspired by the supplied Forge reference. Built with Next.js 16 App Router, React 19, TypeScript and Tailwind CSS 4.

## Run

Requires Node.js 20.9+.

```sh
npm install
npm run dev
```

Open http://localhost:3000. Validate with `npm run typecheck` and `npm run build`; serve a production build with `npm start`.

## Customize

- `app/page.tsx`: page content and sections
- `app/globals.css`: layout, breakpoints, lighting, and CSS hardware
- `components/devices.tsx`: HTML/CSS laptop, navigation, chart, and phone
- `components/actions.tsx`: responsive navigation and accessible native template dialog
- `public/images`: locally hosted photography


Photography: Unsplash mountain and landscape images; sample portraits from randomuser.me.


